@extends('layouts.masteruser')

{{-- {{dd( \Carbon\Carbon::parse( "2021-2-11" )->month )}} --}}
@php
function daysInMonth(\Carbon\Carbon $tanggal, $inclusive = true)
{
	$carbon = \Carbon\Carbon::parse( $tanggal );
	$month = $carbon->month;
	$daysInMonth = $carbon->daysInMonth;
	$from = \Carbon\Carbon::parse( "2021-$month-1" );
	switch ($from->copy()->isoFormat("dddd")) {
		case 'Senin':
			$from = $from->subDays(1);
			break;
		
		case 'Selasa':
			$from = $from->subDays(2);
			break;
		
		case 'Rabu':
			$from = $from->subDays(3);
			break;
		
		case 'Kamis':
			$from = $from->subDays(4);
			break;
		
		case 'Jumat':
			$from = $from->subDays(5);
			break;
		
		case 'Sabtu':
			$from = $from->subDays(6);
			break;
	}
	$to = \Carbon\Carbon::parse( "2021-$month-$daysInMonth" );
	if ($from->gt($to)) {
		return null;
	}

	// Clone the date objects to avoid issues, then reset their time
	$from = $from->copy()->startOfDay();
	$to = $to->copy()->startOfDay();

	// Include the end date in the range
	if ($inclusive) {
		$to->addDay();
	}

	$step = \Carbon\CarbonInterval::day();
	$period = new DatePeriod($from, $step, $to);

	// Convert the DatePeriod into a plain array of Carbon objects
	$range = [];

	foreach ($period as $day) {
		$range[] = new \Carbon\Carbon($day);
	}

	return ! empty($range) ? $range : null;
}
@endphp

@section('content')
<div class="row clearfix">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="card">
			<div class="card-header bg-primary">
				<h2 class="text-white">
					Laporan
				</h2>
			</div>
			<div class="card-body">
				<div class="card-header bg-white">
					<form action="{{route('laporan.update', auth()->user()->username)}}" method="POST" id="formId">
						@csrf
						@method("PUT")
						<div class="flex row">
							<label class="mx-2" style="font-size: 20pt">Tampilkan Bulan :</label>
							<div class="form-group">
							  <input value="{{$tanggal}}" type="month" name="bulan" id="" onchange="document.getElementById('formId').submit()" class="form-control" placeholder="" aria-describedby="helpId">
							</div>
							{{-- <div class="form-group">
							  <input value="{{$tanggal}}" type="number" min="1990" max="2999" name="bulan" id="" onchange="document.getElementById('formId').submit()" class="form-control" placeholder="" aria-describedby="helpId">
							</div> --}}
						</div>
					</form>
				</div>
				<div class="row seven-cols mt-4">
					@foreach ( daysInMonth( \Carbon\Carbon::parse($tanggal) ) as $item)
					<div class="col-lg-1 p-1">
						<div class="card btn p-1 
							{{($item->isoFormat('dddd') == "Minggu") || ($item->isoFormat('dddd') == "Sabtu") ? "btn-outline-danger" : ($item->format("Y-m-d") == \Carbon\Carbon::now()->format("Y-m-d") ? "border-success btn-outline-success":"btn-light")}}">
							<div class="card-body border-none">
								@if ($absensi->where("tanggal", $item->format("Y-m-d"))->isEmpty())
									<a style="font-size:12px">
										<i class="fas fa-times-circle text-danger" aria-hidden="true"></i> Alpa
									</a>
								@else
									<a style="font-size:12px">
										<i class="fas fa-check-circle text-success" aria-hidden="true"></i> Hadir
									</a>
								@endif
								<h4 class="card-title m-0" style="font-size:40px">{{ $item->format("d") }}</h4>
								<p class="m-0 text-dark" style="font-size:13px">{{ $item->isoFormat("dddd") }}</p>
								<p class="m-0 text-primary" style="font-size:12px"> Datang
									@if ($absensi->where("tanggal", $item->format("Y-m-d"))->first() == null)
										<i class="badge badge-warning">--:--</i>
									@else
										<i class="badge badge-primary">{{ $absensi->where("tanggal", $item->format("Y-m-d"))->first()->jam_datang }}</i>
									@endif
								</p>
								<p class="m-0 text-primary" style="font-size:12px"> Pulang
									@if ($absensi->where("tanggal", $item->format("Y-m-d"))->first() == null)
										<i class="badge badge-warning">--:--</i>
									@elseif($absensi->where("tanggal", $item->format("Y-m-d"))->first()->jam_pulang == null)
										<i class="badge badge-primary">--:--</i>
									@else
										<i class="badge badge-primary">{{ $absensi->where("tanggal", $item->format("Y-m-d"))->first()->jam_pulang }}</i>
									@endif
								</p>
							</div>
						</div>
					</div>
					@endforeach
				</div>
			</div>
		</div>
	</div>
</div>


@endsection

@push('css')	
<style type="text/css">
	@media (min-width: 768px){
	.seven-cols .col-md-1,
	.seven-cols .col-sm-1,
	.seven-cols .col-lg-1  {
	  width: 100%;
	  *width: 100%;
	  max-width: 14.285714285714285714285714285714%;
	}
  }
  
  @media (min-width: 992px) {
	.seven-cols .col-md-1,
	.seven-cols .col-sm-1,
	.seven-cols .col-lg-1 {
	  width: 14.285714285714285714285714285714%;
	  *width: 14.285714285714285714285714285714%;
	  max-width: 14.285714285714285714285714285714% !important;
  flex:none !important;
	}
  }
   
  @media (min-width: 1200px) {
	.seven-cols .col-md-1,
	.seven-cols .col-sm-1,
	.seven-cols .col-lg-1 {
	  width: 14.285714285714285714285714285714%;
	  *width: 14.285714285714285714285714285714%;
	  max-width: 14.285714285714285714285714285714% !important;
  flex:none !important;
	}
  }
  </style>
  
  
@endpush
