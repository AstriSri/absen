<?php

function ShortName($name)
{
    $arr_name = explode(" ",$name);
    for ($i=0; $i < count($arr_name); $i++) { 
        if ($i < 3){
            $arr_name[$i] = $arr_name[$i]." ";
        }else{
            $arr_name[$i] = substr($arr_name[$i], 0,1).". ";
        }
    }
    $new_name = implode($arr_name);
    return $new_name;
}

?>